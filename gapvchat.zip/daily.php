<?php
/*
Website : https://jetsource.ir

Telegram : https://t.me/jet_source

Telegram 2 : https://t.me/android9

Password File : www.jetsource.ir
*/

// کرون جاب هر دقیقه یک بار فعال

include "bot.php"; // سازگار با سورس های خودم
$sendtoall = mysqli_fetch_assoc(mysqli_query($connect,"SELECT * FROM sendall  LIMIT 1"));
//===================================================================
if($sendtoall["step"] == "sendall"){
$users = mysqli_query($connect,"select id from user");
while($row = mysqli_fetch_assoc($users)){
     $json[] = $row["id"];
}
$get = $sendtoall["user"];
$plus = $get + 200;
if($sendtoall["msgid"] == false){
for($z = $get;$z <= $plus;$z++){
     bot('sendmessage',[
          'chat_id'=>$json[$z],        
		  'text'=>$sendtoall["text"],
        ]);
}	
}
else
{
for($z = $get;$z <= $plus;$z++){
		bot('sendphoto',[
	'chat_id'=>$json[$z],
	'photo'=>$sendtoall["msgid"],
	'caption'=>$sendtoall["text"],
 ]);
 		bot('sendDocument',[
	'chat_id'=>$json[$z],
	'document'=>$sendtoall["msgid"],
	'caption'=>$sendtoall["text"],
 ]);
}
}
$connect->query("UPDATE sendall SET user = '$plus' LIMIT 1");
if($plus >= count($json)){
  bot('sendmessage',[
      'chat_id'=>$admin[0],
      'text'=>"📍 پیام برای همه کابران ارسال شد",
 ]);
$connect->query("UPDATE sendall SET step = 'none' LIMIT 1");	
}
}
//================================================
if($sendtoall["step"] == "forall"){
$users = mysqli_query($connect,"select id from user");
while($row = mysqli_fetch_assoc($users)){
     $json[] = $row["id"];
}
$get = $sendtoall["user"];
$plus = $get + 200;
for($z = $get;$z <= $plus;$z++){
bot('ForwardMessage',[
'chat_id'=>$json[$z], 
'from_chat_id'=>$sendtoall["chat"],
'message_id'=>$sendtoall["msgid"],
]);
}	
$connect->query("UPDATE sendall SET user = '$plus' LIMIT 1");
if($plus >= count($json)){
  bot('sendmessage',[
      'chat_id'=>$admin[0],
      'text'=>"📍 پیام برای همه کابران فوروارد شد",
 ]);
$connect->query("UPDATE sendall SET step = 'none' LIMIT 1");	
}
}
//=================================================
$daily = mysqli_fetch_assoc(mysqli_query($connect,"SELECT * FROM daily  LIMIT 1"));
if($daily != true){
$connect->query("INSERT INTO `daily` (`run`, `time`, `user`) VALUES ('ok', '', '0')");
}
$daily = mysqli_fetch_assoc(mysqli_query($connect,"SELECT * FROM daily  LIMIT 1"));
$timenow = date("Y-m-d H:i:s");
if($timenow > $daily["time"]){
$users = mysqli_query($connect,"select * from user");
while($row = mysqli_fetch_assoc($users)){
     $json[] = $row["id"];
}
$get = $daily["user"];
$plus = $get + 200;
for($z = $get;$z <= $plus;$z++){
	bot('sendmessage',[
	'chat_id'=>$json[$z],
	'text'=>"🗣 `کاربر عزیز سکه روزانه امروزت امادست !`
🎁 همین الان با استفاده از دکمه '💰 سکه رایگان' میتونی یک سکه رایگان هدیه بگیری",
'parse_mode'=>'Markdown',
    		]);
$connect->query("UPDATE user SET daily = '' WHERE id = '$json[$z]' LIMIT 1");
}
$connect->query("UPDATE daily SET user = '$plus' LIMIT 1");
if($plus >= count($json)){
  bot('sendmessage',[
      'chat_id'=>$admin[2],
      'text'=>"📍 پیام سکه روانه ارسال شد",
 ]);
$time = date("Y-m-d H:i:s", strtotime("+1 day"));
$connect->query("UPDATE daily SET time = '$time' , user = '0' LIMIT 1");	
}
}	
?> 