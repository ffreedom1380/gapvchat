<?php
/*
Website : https://jetsource.ir

Telegram : https://t.me/jet_source

Telegram 2 : https://t.me/android9

Password File : www.jetsource.ir
*/
$MerchantID = 'مرچنت کد شما';
$Amount = $_GET['amount']; 
$Description = 'خرید اشتراک ویژه در ربات چت گرام';
$Email = 'test@gmail.Com';
$Mobile = '09';
$CallbackURL = $_GET['callback'];


$client = new SoapClient('https://www.zarinpal.com/pg/services/WebGate/wsdl', ['encoding' => 'UTF-8']);

$result = $client->PaymentRequest(
[
'MerchantID' => $MerchantID,
'Amount' => $Amount,
'Description' => $Description,
'Email' => $Email,
'Mobile' => $Mobile,
'CallbackURL' => $CallbackURL,
]
);

if ($result->Status == 100) {
Header('Location: https://www.zarinpal.com/pg/StartPay/'.$result->Authority);
} else {
echo'ERR: '.$result->Status;
}
?>